<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'db59f1dnhgezgz' );

/** MySQL database username */
define( 'DB_USER', 'u0xijuhkglzxo' );

/** MySQL database password */
define( 'DB_PASSWORD', 'grs3pwaqqzd0' );

/** MySQL hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '6^-U+H?jba}eWpB6K*PTmX|jNq=3&qmtr/SZ+NG}sVbvBFyV-[/um~9b1q:7%C;)' );
define( 'SECURE_AUTH_KEY',   'G33$#NY{/bL9Z(1P.|P[ZLZ1+fLj^lTHREN<I~H1G<K.Ka,eu7hrDs[p=oH(%{lL' );
define( 'LOGGED_IN_KEY',     'xpqrr+q~=KSqt3Fq6C4NLwl)@Tv7sTXg%VqG+m4.FD)DrL]T9MrlLf2^YPuM2vd ' );
define( 'NONCE_KEY',         'wuGJWBE:O?%LSaYWKt!<N~NvK;G?UmQw<;rkwZ#/`/(bbumAY4}t|OhXQh4F!4$f' );
define( 'AUTH_SALT',         'p@ug6k&J.]4kIc9E/u/e3_I`ncf35hY_~zePM<h:Yb{}}lx?UK-t,-6YaP(;ms``' );
define( 'SECURE_AUTH_SALT',  'pZo@Eb/F_@p]IL@aTB+#VrfFDn7^O3UuQ_&&y{}8_b{ijv8EKv?]@tB{qfuc!|AQ' );
define( 'LOGGED_IN_SALT',    '3`8P,lN?&-Di5c)0LYbqee?TFmfP;Wj|$hW6;GfJid2A_}oq:k&r%QqsqkSJwqya' );
define( 'NONCE_SALT',        '1!T|{25k&s[.yQJf5q.kMI~~5x9yjQ:d6puo|^mX;*nAks8KQ74IXX<cIdR.8t}O' );
define( 'WP_CACHE_KEY_SALT', 'L&0M I/lwU;FQwJ1wbQH6,->nuv/ptcD);u8hW7$TmQvDz=2#tVz<;o<xq=[k{P%' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'qsd_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
@include_once('/var/lib/sec/wp-settings-pre.php'); // Added by SiteGround WordPress management system
require_once ABSPATH . 'wp-settings.php';
@include_once('/var/lib/sec/wp-settings.php'); // Added by SiteGround WordPress management system
